package com.hsbc.ai.jira.plugin.customfields.api;

import com.atlassian.jira.issue.customfields.impl.FieldValidationException;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.customfields.persistence.CustomFieldValuePersister;
import com.atlassian.jira.issue.customfields.persistence.PersistenceFieldType;
import com.atlassian.jira.issue.fields.TextFieldCharacterLengthValidator;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.jira.issue.customfields.impl.AbstractSingleFieldType;


@Scanned
public class PercentCFType extends AbstractSingleFieldType<Integer>{

	public PercentCFType(
			@ComponentImport
			CustomFieldValuePersister customFieldValuePersister,
			
			@ComponentImport
			GenericConfigManager genericConfigManager,
			
			@ComponentImport
			TextFieldCharacterLengthValidator textFieldCharacterLengthValidator,
			
			@ComponentImport
			JiraAuthenticationContext jiraAuthenticationContext) {
		super(customFieldValuePersister, genericConfigManager);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Integer getSingularObjectFromString(String arg0)
			throws FieldValidationException {
		if( arg0 == null)
			return null;
		try
		{
			final Integer percentage = Integer.parseInt( arg0);
			// Check its not bigger than 100
			if( percentage > 100)
			{
				throw new FieldValidationException("A percentage must be between 100 and 0.");
			}
			if( percentage < 0)
			{
				throw new FieldValidationException("A percentage must be between 0 and 100.");
			}
			return percentage;
		}
		catch( NumberFormatException ex)
		{
			throw new FieldValidationException("Not a valid percentage (only whole numbers allowed).");
		}
	}

	@Override
	public String getStringFromSingularObject(Integer arg0) {
		if (arg0 == null)
	        return null;
	    else
	        return arg0.toString();
	}

	@Override
	protected PersistenceFieldType getDatabaseType() {
		 return PersistenceFieldType.TYPE_LIMITED_TEXT;
	}

	@Override
	protected Object getDbValueFromObject(Integer arg0) {
		 return getStringFromSingularObject(arg0);
	}

	@Override
	protected Integer getObjectFromDbValue(Object arg0)
			throws FieldValidationException {
		 return getSingularObjectFromString((String) arg0);
	
	}

}
