package com.hsbc.ai.jira.plugin.customfields.api;

public interface MyPluginComponent
{
    String getName();
}