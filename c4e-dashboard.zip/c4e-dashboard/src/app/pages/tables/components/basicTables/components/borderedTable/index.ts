export * from './borderedTable.component';
