import {Component} from '@angular/core';

@Component({
  selector: 'basic-form',
  template: require('./basicForm.html'),
})
export class BasicForm {

  constructor() {
  }
}
