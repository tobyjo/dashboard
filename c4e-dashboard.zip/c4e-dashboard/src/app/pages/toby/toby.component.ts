import {Component} from '@angular/core';

@Component({
  selector: 'toby',
  template: `<strong>Toby stuff here</strong>`
})
export class TobyComponent {
  constructor() {}
}
