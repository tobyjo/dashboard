import { Routes, RouterModule }  from '@angular/router';
import { TobyComponent } from './toby.component';

const routes: Routes = [
  {
    path: '',
    component: TobyComponent
  }
];

export const routing = RouterModule.forChild(routes);
