import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { TobyComponent } from './toby.component';
import { routing } from './toby.routing';

@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [
    TobyComponent
  ]
})
export default class TobyModule {}
