export class BatteryLevel
{
id:number;
deviceId:number;
deviceName:string
level:number;
reportDate: Date;
}
