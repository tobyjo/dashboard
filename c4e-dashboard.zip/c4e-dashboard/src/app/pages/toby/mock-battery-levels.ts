import {BatteryLevel} from './battery-level.ts';

export const BATTERYLEVELS: BatteryLevel[] = [
{id:1, deviceName:'Hall', deviceId:19, level:75, reportDate:new Date(2012, 12, 05)},
{id:2, deviceName:'Hall', deviceId:19, level:65, reportDate:new Date(2012, 12, 06)}

];
