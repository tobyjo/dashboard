import {Component, ViewEncapsulation} from '@angular/core';


@Component({
  selector: 'typography',
  styles: [],
  template: require('./typography.html'),
})
export class Typography {

  constructor() {
  }
}
