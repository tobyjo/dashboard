import {Component} from '@angular/core';

@Component({
  selector: 'large-buttons',
  template: require('./largeButtons.html'),
})
export class LargeButtons {

  constructor() {
  }
}
