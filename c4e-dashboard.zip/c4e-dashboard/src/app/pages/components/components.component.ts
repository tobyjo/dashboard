import {Component} from '@angular/core';

@Component({
  selector: 'components',
  styles: [],
  template: `<router-outlet></router-outlet>`
})
export class Components {

  constructor() {
  }

}
