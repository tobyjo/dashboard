window['CKEDITOR_BASEPATH'] = '//cdn.ckeditor.com/4.5.9/standard/';
require('ckeditor');
