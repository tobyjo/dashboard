export * from './feed.component';
