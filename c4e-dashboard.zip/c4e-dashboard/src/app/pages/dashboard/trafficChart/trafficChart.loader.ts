export const Chart = require('chart.js');
