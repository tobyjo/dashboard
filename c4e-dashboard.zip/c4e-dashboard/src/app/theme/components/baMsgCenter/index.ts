export * from './baMsgCenter.component';
