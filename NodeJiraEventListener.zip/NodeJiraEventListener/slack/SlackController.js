// SlackController.js
var applog= require('../logger.js');
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var slackRequest = require('request');
router.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
router.use(bodyParser.json()); //for parsing json in request.body



//const VENDOR_ENGAGEMENT = "T2TAAN630/B4W57L99A/HTJtuWt3fJsdYvPRGpj5Er3D";
//const VENDOR_ENGAGEMENT = "T2TAAN630/B5SB0Q2F4/wiA7aV4pLmx44jDa8oK39BFC";
//const AUTOMATION_TESTING_ALERT = "T2TAAN630/B5S7HU2UQ/tENsYNjyWPFckZicyOSowlke";
const hsbcProxy = "http://uk-server-proxy-01.systems.uk.hsbc:80";

// Jira constants
// curl -X POST http://localhost:3000/transition
const slackBaseUrl = "https://hooks.slack.com/services/";

// Format is: Slack?channel=<slack guid>
// Example: http://localhost:3000/slack?channel=T2TAAN630/B5S7HU2UQ/tENsYNjyWPFckZicyOSowlke
// http://localhost:3000/slack?channel=T2TAAN630/B5S7HU2UQ/tENsYNjyWPFckZicyOSowlke&useproxy=true
router.post('/', function (req, res) {
    applog.info("Slack event received");

    var slackChannel = req.query.channel;
    var slackUrl = slackBaseUrl + slackChannel;
   
    if (!slackUrl) {
        applog.error("Unknown Slack channel")
        res.status(200).send('Unknown Slack channel');

    }
    else {
        // Post original body onto slack channel
        var options = {
            uri: encodeURI(slackUrl),
            body: JSON.stringify(req.body),
            // body:JSON.stringify({"text": "This is an automated post"})

        };

        if (req.query.useProxy) {
            if (req.query.useProxy === "true") {
                options.proxy = hsbcProxy;
            }
        }

        slackRequest.post(options, function (err, httpResponse, body) {
            if (err) {
                applog.error("Error calling Slack channel: " + err);
            }

            applog.info(body)
            res.status(200).send(body);
        });
    };


})


module.exports = router;
