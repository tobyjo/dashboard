
var slackRequest = require('request');

function SendSlack()
    var slackUrl = "https://hooks.slack.com/services/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";
   
        var options = {
            uri: encodeURI(slackUrl),
            body:JSON.stringify({"text": "This is an automated post"}),
			proxy:"uk-server-proxy-01.systems.uk.hsbc:80",
			tunnel:true

        };

        slackRequest.post(options, function (err, httpResponse, body) {
            if (err) {
                console.log("Error calling Slack channel: " + err);
            }

            console.log(body)
            res.status(200).send(body);
        });
};

SendSlack();