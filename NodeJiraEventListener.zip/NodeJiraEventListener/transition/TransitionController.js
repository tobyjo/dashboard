// TransitionController.js


var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var request = require('request');
router.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
router.use(bodyParser.json()); //for parsing json in request.body



// Log console to file too
var fs = require('fs');
var util = require('util');
var log_file = fs.createWriteStream('debug.log', { flags: 'w' });
var log_stdout = process.stdout;

console.log = function (d) { //
    log_file.write(util.format(d) + '\n');
    log_stdout.write(util.format(d) + '\n');
};


// Jira constants
// curl -X POST http://localhost:3000/transition
/*
const jiraBaseUrl = "http://localhost:8080/rest/api/2/";
const jiraUser = "toby";
const jiraPassword = "tjones";
const labProject = "IN";
const beProject = "IN";
const labIssueType = "Task";
const labIdCustomField = "customfield_10300";
const labProjectCreatedLabel = "LabProjectCreated";
const researchAreaField = "customfield_10301" // known as Component
*/

// curl -X POST http://128.13.207.110:3000/transition (from jira box)

const jiraBaseUrl = "http://jira-innovation.systems.uk.hsbc:8080/rest/api/2/";
const jiraUser = "jiraevent";
const jiraPassword = "Pur3le1";
const labProject = "LE";
const beProject = "BE";
const labIssueType = "Lab";
const labIdCustomField = "customfield_10302";
const labProjectCreatedLabel = "LabProjectCreated";
const researchAreaField = "customfield_10014" // known as Component


var savedJiraData =
    {
        "originalIssueKey": "",
        "newIssueKey": ""

    }

var newIssueData =
    {
        "fields": {
            "project":
            {
                "key": labProject
            },
            "summary": "",
            "description": "This issue was created automatically. Please add a relevant description.",
            "issuetype": {
                "name": labIssueType
            }
        }
        /*
        "update": {
            "issuelinks": [
                {
                    "add": {
                        "type": {
                            "name": "Relates"
                        },
                        "inwardIssue": {
                            "key": ""
                        }
                    }
                }
            ]
        }
        */
    };


newIssueData.fields[labIdCustomField] = "Please add a Lab Id.";

var issueLinkData = {
    "type": {
        "name": "Relates"
    },
    "inwardIssue": {
        "key": "HSP-1"
    },
    "outwardIssue": {
        "key": "MKY-1"
    },

}

var updateIssueData =
    {
        "update": {
            "labels": [
                {
                    "add": ""
                }
            ]
        }
    }

updateIssueData.update.labels[0].add = labProjectCreatedLabel;

router.get('/', function (req, res) {
    console.log("HTTP GET received. This should be called with HTTP POST.");

    res.status(200).send('Service is active.');
});


router.post('/', function (req, res) {
    console.log("Event received for issue: " + req.body.issue.key);

    // If there are no labels, OR of the label labProjectCreatedLabel is not present then do it
    if (req.body.issue.fields.labels.length === 0 ||
        req.body.issue.fields.labels.indexOf(labProjectCreatedLabel) === -1) {

        if (ResearchAreaIncludesCloud(req.body.issue.fields[researchAreaField])) {

            savedJiraData.originalIssueKey = req.body.issue.key;
            newIssueData.fields.summary = req.body.issue.fields.summary;
            //newIssueData.update.issuelinks[0].add.inwardIssue = savedJiraData.originalIssueKey;

            // Create new issue in Lab Project
            var newIssueOptions = {
                method: 'POST',
                url: jiraBaseUrl + "issue/",
                auth: {
                    user: jiraUser,
                    pass: jiraPassword
                },
                json: true,
                body: newIssueData
            }
            request(newIssueOptions, function (err, httpResponse, body) {
                if (err) {
                    return console.error('Error creating issue on Jira: ', err);
                }

                console.log("Issue created: ", body.key);

                savedJiraData.newIssueKey = body.key;
                issueLinkData.inwardIssue.key = savedJiraData.originalIssueKey;
                issueLinkData.outwardIssue.key = savedJiraData.newIssueKey;

                // Create link between issues
                var addLinkOptions = {
                    method: 'POST',
                    url: jiraBaseUrl + "issueLink/",
                    auth: {
                        user: jiraUser,
                        pass: jiraPassword
                    },
                    json: true,
                    body: issueLinkData
                }

                request(addLinkOptions, function (err, httpResponse, body) {
                    if (err) {
                        return console.error('Error adding link on Jira: ', err);
                    }

                    console.log("Link created");

                    // Update original issue
                    var updateIssueOptions = {
                        method: 'PUT',
                        url: jiraBaseUrl + "issue/" + savedJiraData.originalIssueKey,
                        auth: {
                            user: jiraUser,
                            pass: jiraPassword
                        },
                        json: true,
                        body: updateIssueData
                    }

                    request(updateIssueOptions, function (err, httpResponse, body) {
                        if (err) {
                            return console.error('Error updating original issue on Jira: ', err);
                        }

                        console.log("Original issue updated: " + httpResponse.statusCode);
                    });

                });


            });

        }
        else {
            console.log("But Component does not contain CLOUD as a research area so will not create.");
        }

    }



    else {
        console.log("But " + labProjectCreatedLabel + " already exists on label so will not create again.");
    }
    //console.log(req.body.)
    res.status(200).send('Event received');
})

function ResearchAreaIncludesCloud(researchAreas) {
    if (researchAreas != null) {
        for (var i = 0, len = researchAreas.length; i < len; i++) {
            if (researchAreas[i].value === "CLOUD") {
                return true;
            }

        }
    }
    return false;
}

module.exports = router;
