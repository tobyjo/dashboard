var request = require('request');
var j = request.jar();
var request = request.defaults({ jar: j }) //it will make the session default for every request
var consts = require('./jiraconsts.js');
var applog = require('./logger.js');


exports.jiraLogin = function (usersToDeactivate, callback) {
    applog.info("Login to Jira");

    request({
        url: consts.jiraUrl + "login.jsp",
        method: "GET"
    },

        // Login
        function (error, response, body) {
            request({
                url: consts.jiraUrl + "login.jsp",
                method: "POST",
                form: { os_username: consts.jiraAdminUser, os_password: consts.jiraAdminPassword }
            },
                function (error, response, body) {
                    var cookies = j.getCookies(consts.jiraUrl);
                    var xsrfToken = cookies[0].value;
                    return callback(usersToDeactivate, xsrfToken);

                });

        });
}

exports.deactivateUser = function (this_username, this_firstname, this_lastname, this_email, this_xsrfToken, callback) {
    // Must turn off second Administrator password prompt for this to work as is
    request({
        url: consts.jiraUrl + "secure/admin/user/EditUser.jspa",
        method: "POST",
        form: { username: this_username, fullName: this_firstname + " " + this_lastname, email: this_email, editName: this_username, atl_token: this_xsrfToken }
    }, function (error, response, body) {
        if (body.length > 0) {
            applog.error("Could not deactivate user " + this_username);
        }
        return callback();
    });


}

