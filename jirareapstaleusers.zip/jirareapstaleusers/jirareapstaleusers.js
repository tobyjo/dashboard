// This program will set to inactive any Jira user that has not logged on in x days *see jiraconsts.js)
// Toby Jones

var mysql = require('mysql');
var applog = require('./logger.js');
var consts = require('./jiraconsts.js');
var userstatus = require('./changeuseractivestatus.js');
var xsrfToken;
var numUsersLeftToDeactivate;

var connection = mysql.createConnection({
    host: consts.mysql_host,
    user: consts.mysql_user,
    password: consts.mysql_password,
    database: consts.mysql_database
});



var sqlQuery = "SELECT d.directory_name AS 'Directory', " +
    "u.user_name AS 'Username', " +
    "u.first_name, " +
    "u.last_name, " +
    "email_address, " +
    "u.active, " +
    "DATEDIFF(Now(), from_unixtime((cast(attribute_value AS UNSIGNED)/1000))) AS 'dayssincelogin', " +
    "from_unixtime((cast(attribute_value AS UNSIGNED)/1000)) AS 'LastLogin' " +
    "FROM cwd_user u " +
    "JOIN ( " +
    "SELECT DISTINCT child_name " +
    "FROM cwd_membership m " +
    "JOIN globalpermissionentry gp ON m.parent_name = gp.group_id " +
    "WHERE gp.group_id = 'jira-software-users' " +
    ") AS m ON m.child_name = u.user_name " +
    "LEFT JOIN ( " +
    "SELECT * " +
    "FROM cwd_user_attributes " +
    "WHERE attribute_name = 'login.lastLoginMillis' " +
    ") AS a ON a.user_id = u.id " +
    "JOIN cwd_directory d ON u.directory_id = d.id " +
    // "WHERE d.directory_name IN ('HSBC LDAP') " +
    "WHERE d.directory_name IN ('JIRA Internal Directory') " +
    "AND DATEDIFF(Now(), from_unixtime((cast(attribute_value AS UNSIGNED)/1000))) > " + consts.numdayssincelastlogin + " " +
    "AND u.active = 1 " +
    "ORDER BY LastLogin ASC;";

connection.connect(function (err) {
    if (err) {
        applog.error('Error connecting to MySQL db: ' + err.stack);
        return;
    }

    applog.info('Connected to MySQL db as id ' + connection.threadId);

    connection.query(sqlQuery, function (error, results, fields) {
        applog.info(results.length + " users found that have not logged on in the last " + consts.numdayssincelastlogin + " days.");

        if (results.length > 0) {
            numUsersLeftToDeactivate = results.length;
            userstatus.jiraLogin(results, DeactivateUsers);

        }
        else
        {
          CloseMySQLConnection();
        }

    });

});

function DeactivateUsers(usersToDeactivate, xsrfToken) {
    // This will call the function to set each of these users to inactive
    for (var i = 0; i < usersToDeactivate.length; i++) {
        //console.log(results[i].Username + "," + results[i].first_name + " " + results[i].last_name + "," + results[i].dayssincelogin);
        applog.info("Deactivating user: " + usersToDeactivate[i].Username + "," + usersToDeactivate[i].first_name + " " + usersToDeactivate[i].last_name + "," + usersToDeactivate[i].dayssincelogin);
        userstatus.deactivateUser(usersToDeactivate[i].Username, usersToDeactivate[i].first_name, usersToDeactivate[i].last_name, usersToDeactivate[i].email_address, xsrfToken, WhenFinishedDeactivation)
    }

}

function WhenFinishedDeactivation() {
    numUsersLeftToDeactivate--;
    if (numUsersLeftToDeactivate == 0) {
        CloseMySQLConnection();

    }
}

function CloseMySQLConnection() {
    applog.info("Closing MySQL connection");
    connection.end(function (err) {
        // Connection close.
        if (err) {
            applog.error('Error termination MySQL connection: ' + err.stack);
            process.exit(1);
        }
        process.exit(0);
    });
}