// run on AWS
exports.jiraUrl="https://www.maplequad.com/";
exports.mysql_host = 'oregon-jira-mysql.cv3qlczr6mt6.us-west-2.rds.amazonaws.com';
exports.mysql_user = 'jiramaster';
exports.mysql_password = 'J3llyTr3ad';
exports.mysql_database = 'jiradb';
exports.jiraAdminUser="jonest";
exports.jiraAdminPassword="Wh1te1";

// run on gbl20016050
/*
exports.jiraUrl="http://localhost:8080/";
exports.mysql_host = 'localhost';
exports.mysql_user = 'root';
exports.mysql_password = 'Austr4lia$';
exports.mysql_database = 'jiradb';
exports.jiraAdminUser="jonest";
exports.jiraAdminPassword="Wh1te1";
*/

//exports.numdayssincelastlogin = 40; for live
//exports.numdayssincelastlogin = 180; for AWS - HSBC LDAP
exports.numdayssincelastlogin = 40; // for AWS - local users