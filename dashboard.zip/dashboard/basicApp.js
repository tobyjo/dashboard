var server=require('./node_modules/node-http-server/server/http.js');

console.log(server);

server.deploy(
    {
        verbose: true,
        port: 8000,
        root:__dirname+'/appRoot/'
		
    }
);
