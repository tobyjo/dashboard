# JiraReports
Takes results from Jira and displays various reports using D3.JS Javascript library.

To start the web server run

`node basicApp.js`

Relies on node cron job to fetch data from Jira and place output into jiradumps folder.
