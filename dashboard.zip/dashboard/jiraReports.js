var server=require('./node_modules/node-http-server/server/http.js');
var log4js = require('log4js');
const port = 8000;

server.beforeServe=beforeServe;

const logfilename = __dirname + '/../logs/dashboard.log';
log4js.configure({
  appenders: { fileoutput: { type: 'file', filename: logfilename, maxLogSize: 10485760, backups: 3 },
 							console: {type: 'stdout'}},
  categories: { default: { appenders: ['fileoutput', 'console'], level: 'info' } }
});

logger = log4js.getLogger('fileoutput');

logger.info("Dashboard (jirareports) started on port " + port);

server.deploy(
    {
        verbose: false,
        port: port,
        root:__dirname+'/appRoot/'

    }
);

function beforeServe(request,response,body,encoding)
{
  if( request.url.endsWith('html'))
  {
    logger.info(request.url);
  }
};
