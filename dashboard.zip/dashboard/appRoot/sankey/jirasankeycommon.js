// This module contains the common "classes" used in our HSBC code to take the output from JIRA REST API JSON
// format and turn it into JSON suitable for the Sankey chart


function NodeEntry(nodeName, jiraField)
{
	this.name = nodeName;
	this.jiraField = jiraField; // We need to capture the jira field name so we can create url to it within sankey chart
}
function LinkEntry( source, target, value )
{
	this.source = source;
	this.target = target;
	this.value = value;
}

// This holds the structure that SanKey class needs as JSON input
function NewJson()
{
	
		this.links = [];
		this.nodes = [];
		this.errors = [];
	
	this.addNode = function( node, jiraField)
	{
		if( node )
		{
			var nodeObj = new NodeEntry(node, jiraField);
			var nodeAlreadyAddedTest = $.grep(this.nodes, function(obj) { return obj.name == node; })
			if( nodeAlreadyAddedTest.length === 0)
			{
				this.nodes.push(nodeObj);
			}
		}
	}
	
	this.addLink = function(source, target, issueKey)
	{
		var foundExistingIndex = -1;
		$.each( this.links, function( index, value)
		{
			if( value.source === source && value.target === target)
			{
				foundExistingIndex = index;
				return false;
			}
				
		});
		
		var valueAmount = 1;
		if( foundExistingIndex >= 0)
		{
			valueAmount = this.links[foundExistingIndex].value + 1;
			this.links[foundExistingIndex].value = valueAmount;
		}
		else
		{
			// Now check for a match using the target as source an vice versa.
			// If there is a match this will result in a cyclic dependency which, with the standard sankey.js,
			// result in the browser hanging, but now with the fix means that the central node will be on the rhs.
			// So this will place the cyclic dependency in an errors list and will not add it to the links array.
			var foundCyclicIndex = -1;
			$.each( this.links, function( index, value)
			{
				if( value.source === target && value.target === source)
				{
					foundCyclicIndex = index;
					return false;
				}
					
			});
			
			if( foundCyclicIndex >= 0)
			{
				this.errors.push("<li><a href='" + JIRA_URL + issueKey + "'>" + issueKey + "</a> Cyclic relationship found on source: <strong>" + source + "</strong>, target: <strong>" + target + "</strong></li>");
			}
			else
			{
				var linkEntry = new LinkEntry( source, target, valueAmount)
				this.links.push(linkEntry);
			}
		}
	}
	
}

if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(searchString, position) {
    position = position || 0;
    return this.indexOf(searchString, position) === position;
  };
}