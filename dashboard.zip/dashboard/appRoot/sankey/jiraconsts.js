// This module contains constants for using with Innivations Jira
// http://jira-innovation.systems.uk.hsbc:8080/rest/api/latest/search?jql=project=%22Business%20Engagement%22&maxResults=1000&fields=summary,customfield_10014,customfield_10015,customfield_10009,customfield_10600
// Business Sponsor: customfield_10009
// Line of Business: customfield_10015 (array)
// Component: customfield_10014 (array)
// Lab Location: customfield_10060 

const CUSTOMFIELD_BUSINESS_SPONSOR = 'customfield_10009';
const CUSTOMFIELD_LINE_OF_BUSINESS = 'customfield_10015';
const CUSTOMFIELD_COMPONENT = 'customfield_10014';
const CUSTOMFIELD_LAB_LOCATION = 'customfield_10600';

const UNKNOWN_VALUE_PREFIX = "Unidentified";
const DEFAULT_BUSINESS_SPONSOR = UNKNOWN_VALUE_PREFIX + ' sponsor'
const DEFAULT_LINE_OF_BUSINESS = UNKNOWN_VALUE_PREFIX + ' line of business';
const DEFAULT_COMPONENT = UNKNOWN_VALUE_PREFIX + ' component';
const DEFAULT_LAB_LOCATION =  UNKNOWN_VALUE_PREFIX + ' lab location';
const JIRA_URL = "http://jira-innovation.systems.uk.hsbc:8080/projects/BE/issues/";

const JIRA_INCHART_LINK_URL = 'http://jira-innovation.systems.uk.hsbc:8080/issues/?jql=';
//const JIRA_INCHART_LINK_URL = encodeURI('http://jira-innovation.systems.uk.hsbc:8080/issues/?jql=' + 'project="Business Engagement" and "Business Sponsor"  ~ "Remi"')