
// Fields associated with one issue
function IssueFields(businessSponsor, lineOfBusinesses, labLocation, issueKey)
{

		this.businessSponsor = businessSponsor;
		this.lineOfBusinesses = lineOfBusinesses;
		this.labLocation = labLocation;
		this.issueKey = issueKey;
		//this.components = components;

}



function addLineOfBusiness_LabLocation_BusinessSponsor (issueFields, newJson)
	{
		// go through each array

		$.each(issueFields.lineOfBusinesses, function (index, lineOfBusiness)
		{
			newJson.addLink( lineOfBusiness, issueFields.labLocation, issueFields.issueKey);
			newJson.addLink( issueFields.labLocation, issueFields.businessSponsor, issueFields.issueKey);

		});
	}



function loadAndParseJiraJson(jsonFileName)
{
	var convertedjson;
	// Loop thru json object and place into new json object

			var newJson = new NewJson();

	// load JSON from Jira REST API call ( actually from a file )
	$.getJSON(jsonFileName, function( oldJson) {

		// Go through each issue and format into JSON structure required for D3.js charts for Sankey diagram
		$.each( oldJson.issues, function( key, val) {

			// Fields to store values just for this issue
			var lineOfBusinessArray = [];
			var componentArray = [];
			var businessSponsor;
			var labLocation;
			var issueKey = val.key; // save issue key to help in locating any errors we find

			// Go thru all the fields
			$.each( val.fields, function( key1, val1) {

				// Line of Business
				if( key1 === CUSTOMFIELD_LINE_OF_BUSINESS )
				{
					$.each( val1, function( key2, val2) {
							lineOfBusinessArray.push(val2.value);
							newJson.addNode(val2.value, CUSTOMFIELD_LINE_OF_BUSINESS);

					});

				}
				// Component
				/*
				else if( key1 === CUSTOMFIELD_COMPONENT )
				{
					$.each( val1, function( key2, val2) {
						componentArray.push(val2.value);
						newJson.addNode(val2.value);

					});
				}
				*/

				// Business Sponsor
				else if( key1 === CUSTOMFIELD_BUSINESS_SPONSOR )
				{
					businessSponsor = val1;
					newJson.addNode(businessSponsor, CUSTOMFIELD_BUSINESS_SPONSOR);
				}

				// Lab Location
				else if( key1 === CUSTOMFIELD_LAB_LOCATION )
				{
					// Since this is a single select list this may be null so have to check before we start using its properties
					if( val1)
					{
						labLocation = val1.value;
						newJson.addNode(labLocation, CUSTOMFIELD_LAB_LOCATION);
					}
				}


			});

			// Set defaults if not set
			if( !businessSponsor)
			{
				businessSponsor = DEFAULT_BUSINESS_SPONSOR;
				newJson.addNode(DEFAULT_BUSINESS_SPONSOR, CUSTOMFIELD_BUSINESS_SPONSOR);
			}
			if( lineOfBusinessArray.length === 0)
			{
				lineOfBusinessArray.push(DEFAULT_LINE_OF_BUSINESS );
				newJson.addNode(DEFAULT_LINE_OF_BUSINESS, CUSTOMFIELD_LINE_OF_BUSINESS);
			}
			if( !labLocation)
			{
				labLocation = DEFAULT_LAB_LOCATION;
				newJson.addNode(DEFAULT_LAB_LOCATION, CUSTOMFIELD_LAB_LOCATION);
			}
			// Add fields for this issue to our global list
			addLineOfBusiness_LabLocation_BusinessSponsor( new IssueFields(businessSponsor, lineOfBusinessArray, labLocation, issueKey), newJson );



		});

		 DumpNewJson( newJson);

		 // Display Sankey with the data in the correct format
		 DisplaySankey( newJson);

		 // Show any errors found
		 if( newJson.errors.length > 0)
		 {
			$( "#errorList" ).html("<ul>" + newJson.errors + "</ul>");
			$("#showErrors").toggle(1000);
		 }

	} )


}

// Given a jira field i.e. business sponsor, and a value, it will create the url link to search for this term.
function GetQueryUrlForField( jiraField, jiraValue)
{
	var partUrl = "";
	switch( jiraField )
	{
		case CUSTOMFIELD_BUSINESS_SPONSOR:
			if( jiraValue.startsWith(UNKNOWN_VALUE_PREFIX) )
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Business Sponsor" is empty');
			}
			else
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Business Sponsor"  ~ "' + jiraValue + '"');
			}
			break;
		case CUSTOMFIELD_LINE_OF_BUSINESS:
			if( jiraValue.startsWith(UNKNOWN_VALUE_PREFIX) )
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Line of Business" is empty');
			}
			else
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Line of Business"  = "' + jiraValue + '"');
			}
			break;
		case CUSTOMFIELD_LAB_LOCATION:
			if( jiraValue.startsWith(UNKNOWN_VALUE_PREFIX) )
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Lab Location" is empty');
			}
			else
			{
				partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement" and "Lab Location"  in ("' + jiraValue + '")');
			}
			break;
		default:
			partUrl = encodeURI(JIRA_INCHART_LINK_URL + 'project="Business Engagement"'); // just get all issues as default - shouldnt happen
			break;
	}
	return partUrl;
}

function DumpNewJson( newJson)
{
	var jSon = JSON.stringify(newJson); // Convert object to a JSON structure as a string
	console.log(jSon);
}
