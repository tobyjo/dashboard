// If creating a new file dont forget to add module.export = router seend at bof
var applog = require('../logger.js');
var express = require('express');
var router = express.Router();
var request = require('request');

var reactivate = require('../reactivateuser.js');


router.get('/reactivate/:username', function (req, res) {
    applog.info("user/reactivate/" + req.params.username);
 
 if( req.params.username != null)
 {
     reactivate.jiraLogin(req.params.username, ReactivateUser);

     // Note we return here so we dont end up sending two results back (by sending the other res.status too)
     return res.status(200).send('Please try to login to Jira now.');
     
 }
   res.status(400).send('No username supplied.');
});

function ReactivateUser(userToReactivate, xsrfToken) {
         applog.info("Reactivating user: " + userToReactivate);
        reactivate.reactivateUser(userToReactivate, xsrfToken)
   
}

module.exports = router;