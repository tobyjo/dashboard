var log4js = require('log4js');

const logfilename = __dirname + '/../logs/jirareactivateuser.log';
log4js.configure({
    appenders: {fileoutput: {type:'file', filename: logfilename, maxLogSize: 10485760, backups:3},
    console: {type:'stdout'}},
    categories: {default:{appenders:['fileoutput', 'console'], level:'info'}}
});

var logger = log4js.getLogger();

module.exports = logger;