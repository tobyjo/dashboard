// run on local VM
exports.jiraUrl="http://192.168.122.1:8080/";
exports.jiraAdminUser="toby";
exports.jiraAdminPassword="tjones";

// run on gbl20016050
/*
exports.jiraUrl="http://localhost:8080/";
exports.jiraAdminUser="jonest";
exports.jiraAdminPassword="Wh1te1";
*/
