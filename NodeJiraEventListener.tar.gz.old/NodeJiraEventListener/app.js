// app.js
var express = require('express');
var app = express();


var TransitionController = require('./transition/TransitionController');
app.use('/transition', TransitionController);


module.exports = app;