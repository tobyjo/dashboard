// TransitionController.js


var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var request = require('request');
router.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
router.use(bodyParser.json()); //for parsing json in request.body
var jiraRequest = require('request')


// Jira constants
// curl -X POST http://localhost:3000/transition
const jiraBaseUrl = "http://localhost:8080/rest/api/2/";
const jiraUser = "toby";
const jiraPassword = "tjones";
const labProject = "IN";
const beProject = "IN";


var data =
    {
       "fields": {
            "project":
            { 
                "key": labProject
            },
            "summary": "Tobys new Task",
            "description": "Creating from nodejs.",
            "issuetype": {
                "name": "Task"
            }
       }
    };



router.post('/', function(req, res)
{
    console.log("Event received");

 // Create new issue in Lab Project
 var options = {
    method:'POST',
    url: jiraBaseUrl + "issue/",
    auth: {
        user: jiraUser,
        pass: jiraPassword
    },
    json:true,
    body:data
 }
    request(options, function(err, httpResponse, body){
        if( err)
        {
            return console.error('Error creating issue on Jira: ', err);
        }

        console.log("Issue created: ", body);
    });
   
   

    //console.log(req.body.)
    res.status(200).send('Event received');
})



module.exports = router;