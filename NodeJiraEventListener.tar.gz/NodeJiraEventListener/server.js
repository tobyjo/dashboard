// server.js

var applog= require('./logger.js');
var app = require('./app');
var port = process.env.PORT || 3000;
//var port = 80;
var server = app.listen(port, function() {
  applog.info('Express server listening on port ' + port);
});

