// app.js
var express = require('express');

var app = express();

var TransitionController = require('./transition/TransitionController');
app.use('/transition', TransitionController);

var SlackController = require('./slack/SlackController');
app.use('/slack', SlackController);

module.exports = app;